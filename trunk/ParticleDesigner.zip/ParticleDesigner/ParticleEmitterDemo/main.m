//
//  main.m
//  ParticleEmitterDemo
//
//  Created by Mike Daley on 12/05/2010.
//  Copyright 71Squared 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
