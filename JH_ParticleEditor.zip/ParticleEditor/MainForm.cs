﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ParticleEditor
{
    public partial class MainForm : Form
    {
        public enum Buttons { TitleBar = 0 };
        public enum TitleBarButton { Min, Max, Close };

        public MainForm()
        {
            InitializeComponent();


            //SetTitleBar();
        }


        private bool m_bTopMoiseDown = false;
        private Point m_ptMoveStart = new Point(0, 0);
        private int m_iType = -1;
        private Point m_ptSizingStartPoint = new Point(0, 0);
        bool m_bMainMouseDown = false;
        Size m_szCurrent = new Size(0, 0);

        private void pnTop_MouseDown(object sender, MouseEventArgs e)
        {
            m_bTopMoiseDown = true;
            m_ptMoveStart = this.PointToScreen(new Point(e.X, e.Y));
        }

        private void pnTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (m_bTopMoiseDown)
            {
                Point ptTarget = this.PointToScreen(new Point(e.X, e.Y));

                this.Location = new Point(this.Location.X + (ptTarget.X - m_ptMoveStart.X), this.Location.Y + (ptTarget.Y - m_ptMoveStart.Y));
                m_ptMoveStart = ptTarget;
            }
        }

        private void pnTop_MouseUp(object sender, MouseEventArgs e)
        {
            m_bTopMoiseDown = false;
        }

        private void Main_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;

        }

        private void Main_MouseDown(object sender, MouseEventArgs e)
        {
            m_bMainMouseDown = true;
            m_ptSizingStartPoint = this.PointToScreen(new Point(e.X, e.Y));
        }

        private void Main_MouseUp(object sender, MouseEventArgs e)
        {
            m_bMainMouseDown = false;
        }

        private void Main_MouseMove(object sender, MouseEventArgs e)
        {
            if (m_bMainMouseDown)
            {
                Point ptTarget = this.PointToScreen(new Point(e.X, e.Y));

                int iXGap = (ptTarget.X - m_ptSizingStartPoint.X);
                int iYGap = (ptTarget.Y - m_ptSizingStartPoint.Y);

                //int iTopBottom = ((m_iType == 1) || (m_iType == 2) || (m_iType == 3) || (m_iType == 4) || (m_iType == 6)) ? 0 : 1;

                //if (iTopBottom == 0)
                //{
                //    if ((iXGap > 0) && (this.Width == this.MinimumSize.Width))
                //        return;
                //}
                //else
                //{
                //    if ((iYGap > 0) && (this.Height == this.MinimumSize.Height))
                //        return;
                //}

                // 1: Top, 2: Top-Left, 3: Top-Right, 4: Left, 5: Right, 6: Bottom-Left, 7: Bottom-Right, 8: Bottom
                switch (m_iType)
                {
                    case 1:
                        if ((iYGap > 0) && (this.Height == this.MinimumSize.Height))
                            return;

                        this.Location = new Point(this.Location.X, this.Location.Y + iYGap);
                        this.Size = new Size(this.Size.Width, this.Size.Height - iYGap);
                        break;
                    case 2:
                        if (((iXGap > 0) && (this.Width == this.MinimumSize.Width)) || ((iYGap > 0) && (this.Height == this.MinimumSize.Height)))
                            return;

                        this.Location = new Point(this.Location.X + iXGap, this.Location.Y + iYGap);
                        this.Size = new Size(this.Size.Width - iXGap, this.Size.Height - iYGap);
                        break;
                    case 3:

                        this.Location = new Point(this.Location.X, this.Location.Y + iYGap);
                        this.Size = new Size(this.Size.Width + iXGap, this.Size.Height - iYGap);
                        break;
                    case 4:
                        if ((iXGap > 0) && (this.Width == this.MinimumSize.Width))
                            return;

                        this.Location = new Point(this.Location.X + iXGap, this.Location.Y);
                        this.Size = new Size(this.Size.Width - iXGap, this.Size.Height);

                        break;
                    case 5:


                        this.Location = new Point(this.Location.X + iXGap, this.Location.Y + iYGap);
                        this.Size = new Size(this.Size.Width + iXGap, this.Size.Height);
                        break;
                    case 6:


                        this.Location = new Point(this.Location.X + iXGap, this.Location.Y);
                        this.Size = new Size(this.Size.Width - iXGap, this.Size.Height + iYGap);
                        break;
                    case 7:
                        //this.Location = new Point(this.Location.X + iXGap, this.Location.Y + iYGap);
                        this.Size = new Size(this.Size.Width + iXGap, this.Size.Height + iYGap);
                        break;
                    case 8:
                        this.Size = new Size(this.Size.Width, this.Size.Height + iYGap);
                        break;
                    case 0:
                    default:
                        return;
                }
                m_ptSizingStartPoint = ptTarget;
            }
            else
            {
                SetCursorType(e.X, e.Y);
            }
        }

        private void SetCursorType(int iX, int iY)
        {
            int iWidth = this.ClientRectangle.Width;
            int iHeight = this.ClientRectangle.Height;

            int iPositionX = (iX < 10) ? 0 : ((iX > (iWidth - 10) ? 2 : 1));
            int iPositionY = (iY < 10) ? 0 : ((iY > (iHeight - 10) ? 2 : 1));

            switch (iPositionX)
            {
                case 0:
                    switch (iPositionY)
                    {
                        case 0:
                            m_iType = 2;
                            this.Cursor = Cursors.SizeNWSE;
                            break;
                        case 1:
                            m_iType = 4;
                            this.Cursor = Cursors.SizeWE;
                            break;
                        case 2:
                            m_iType = 6;
                            this.Cursor = Cursors.SizeNESW;
                            break;
                    }
                    break;
                case 1:
                    switch (iPositionY)
                    {
                        case 0:
                            m_iType = 1;
                            this.Cursor = Cursors.SizeNS;
                            break;
                        case 1:
                            m_iType = 0;
                            this.Cursor = Cursors.Default;
                            break;
                        case 2:
                            m_iType = 8;
                            this.Cursor = Cursors.SizeNS;
                            break;
                    }
                    break;
                case 2:
                    switch (iPositionY)
                    {
                        case 0:
                            m_iType = 3;
                            this.Cursor = Cursors.SizeNESW;
                            break;
                        case 1:
                            m_iType = 5;
                            this.Cursor = Cursors.SizeWE;
                            break;
                        case 2:
                            m_iType = 7;
                            this.Cursor = Cursors.SizeNWSE;
                            break;
                    }
                    break;
            }
        }

        private void lbClose_MouseUp(object sender, MouseEventArgs e)
        {
            this.Close();
        }

        private void lbMax_MouseUp(object sender, MouseEventArgs e)
        {
            FormWindowState wsCurrent = this.WindowState;
            m_szCurrent = this.Size;

            switch (wsCurrent)
            {
                case FormWindowState.Normal:
                    this.WindowState = FormWindowState.Maximized;

                    break;
                case FormWindowState.Maximized:
                    this.WindowState = FormWindowState.Normal;
                    break;

            }
        }
        
        private void lbMin_MouseUp(object sender, MouseEventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pnTop_DoubleClick(object sender, EventArgs e)
        {
            FormWindowState wsCurrent = this.WindowState;
            m_szCurrent = this.Size;

            switch (wsCurrent)
            {
                case FormWindowState.Normal :
                    this.WindowState = FormWindowState.Maximized;
                    
                    break;
                case FormWindowState.Maximized :
                    this.WindowState = FormWindowState.Normal;
                    break;

            }
        }

        private void lbMin_MouseMove(object sender, MouseEventArgs e)
        {
            lbMin.Image = ParticleEditor.Properties.Resources.img_minimize_over;
        }

        private void lbMin_MouseLeave(object sender, EventArgs e)
        {
            lbMin.Image = ParticleEditor.Properties.Resources.img_minimize_nor;
        }

        private void lbMax_MouseMove(object sender, MouseEventArgs e)
        {
            lbMax.Image = ParticleEditor.Properties.Resources.img_maximize_over;
        }

        private void lbMax_MouseLeave(object sender, EventArgs e)
        {
            lbMax.Image = ParticleEditor.Properties.Resources.img_maximize_nor;
        }

        private void lbClose_MouseMove(object sender, MouseEventArgs e)
        {
            lbClose.Image = ParticleEditor.Properties.Resources.img_close_over;
        }

        private void lbClose_MouseLeave(object sender, EventArgs e)
        {
            lbClose.Image = ParticleEditor.Properties.Resources.img_close_nor;
        }
    }
}
