﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace ParticleEditor
{
    public partial class CP_Buttons : Label
    {
        public CP_Buttons()
        {

        }
    }
}
